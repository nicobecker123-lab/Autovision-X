# License not selected

This repository is intended to be public, but public visibility does not automatically grant permission to reuse, modify, or redistribute its contents.

No open-source license has been selected for this initial package. Choose a license before inviting external contributions or encouraging reuse. If you intend proprietary rights, obtain appropriate legal guidance before publishing.
