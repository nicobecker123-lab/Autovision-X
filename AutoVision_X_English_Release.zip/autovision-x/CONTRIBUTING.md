# Contributing

1. Keep the design axioms intact, especially `MATERIALIZATION != REALITY` and `ZERO-OVERCLAIM`.
2. Do not commit credentials, access tokens, private keys, customer data, or private logs.
3. Label simulated and placeholder data explicitly.
4. For each new component, document purpose, states, evidence requirements, accessibility, and failure behavior.
5. Add tests for any executable behavior and state exactly what the tests cover.
6. Avoid claiming production readiness without reproducible evidence.
7. Respect reduced-motion settings and keep audio opt-in.
