#!/usr/bin/env python3
"""Validate AutoVision X design-token JSON structure and required color tokens."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = {
    "hyper-dark": "#080C14",
    "hyper-surface": "#0E1524",
    "hyper-border": "#1F2B42",
    "hyper-cyan": "#00E5FF",
    "hyper-green": "#00FFAA",
    "hyper-magenta": "#FF007F",
    "hyper-yellow": "#FFEA00",
    "laser-core": "#FF0000",
}

def fail(message: str) -> None:
    print(f"FAIL: {message}")
    raise SystemExit(1)

def main() -> None:
    token_dir = ROOT / "design-tokens"
    for path in sorted(token_dir.glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            fail(f"{path.relative_to(ROOT)} is not valid JSON: {exc}")
        if not isinstance(data, dict):
            fail(f"{path.relative_to(ROOT)} must contain a JSON object")

    color_path = token_dir / "colors.json"
    try:
        colors = json.loads(color_path.read_text(encoding="utf-8"))["tokens"]
    except Exception as exc:
        fail(f"cannot read color tokens: {exc}")

    for name, expected in REQUIRED.items():
        token = colors.get(name)
        if not token:
            fail(f"missing color token: {name}")
        actual = token.get("value")
        if actual != expected:
            fail(f"{name}: expected {expected}, found {actual}")

    print("PASS: token JSON parses and required color values match.")
    print("LIMIT: this does not validate visual rendering, accessibility, security, or runtime behavior.")

if __name__ == "__main__":
    main()
