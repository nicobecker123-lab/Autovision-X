# GitHub setup — autovision-x

Target account: `nicobecker123-lab`
Target repository: `autovision-x`
Desired visibility: **Public**

## 1. Create the repository

Open https://github.com/new while signed into `nicobecker123-lab`.

- Repository name: `autovision-x`
- Description: `Hyperdub Forensic Cyberpunk design system for evidence-aware telemetry interfaces`
- Visibility: **Public**
- For the cleanest upload, do not initialize with a README, `.gitignore`, or license (this package already contains its own README and `.gitignore`).
- Select **Create repository**.

## 2. Upload using the GitHub website

- Open the new repository.
- Choose **Add file → Upload files**.
- Extract `autovision-x-upload.zip` locally first, then drag the *contents* of the `autovision-x/` folder into the upload area.
- Enter commit message: `Initial AutoVision X design-system foundation`.
- Choose **Commit changes**.

GitHub's web uploader has practical file/size limits. This package is small; for later larger projects, use Git.

## 3. Alternative: Git CLI

Extract the archive and run these commands from the extracted `autovision-x` folder after creating the empty GitHub repository:

```bash
git init
git add .
git commit -m "Initial AutoVision X design-system foundation"
git branch -M main
git remote add origin https://github.com/nicobecker123-lab/autovision-x.git
git push -u origin main
```

If Git prompts for authentication, use Git Credential Manager or a supported GitHub authentication method. Do not paste a token into source files or commit it.

## 4. Verify after upload

- Open `https://github.com/nicobecker123-lab/autovision-x`.
- Confirm the repository is public and the initial files appear.
- Open `README.md` and check relative links.
- Run `python scripts/validate_tokens.py` locally.
- Confirm the repository contains no secrets before sharing it.

The target URL above is the intended destination, not confirmation that the repository currently exists or has been published.
