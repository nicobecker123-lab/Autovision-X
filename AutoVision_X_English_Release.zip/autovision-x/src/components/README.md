# Component starter area

This directory is reserved for implementation. Current component definitions live in [`../../docs/COMPONENT_CONTRACTS.md`](../../docs/COMPONENT_CONTRACTS.md).

No production React, Vue, or Web Component implementation is included yet. Choose the target framework before adding framework-specific source files.
