# Audio Suite // System OS

Contains specifications and implementations for the tactile acoustic feedback layer.

- `BOOT_STINGER.md`: Planned Nokia-2000s boot cue via Suno ([Audio Link](https://suno.com/s/GLrbClR6VusQhJaj))
- `FAVOURITE_TRACK.md`: ⭐ **Curated Favourite / Core System Anthem** ([Audio Link](https://suno.com/s/C9tg1ssd3GnXeDhH))
- `ForensicAudioEngine.js`: Mathematical Web Audio synthesis (Triangle, Sine, Sawtooth oscillators)
- [`../../docs/AUDIO_SYNTHESIS.md`](../../docs/AUDIO_SYNTHESIS.md): Comprehensive Audio Synthesis Contract
