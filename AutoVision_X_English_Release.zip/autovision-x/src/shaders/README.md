# Shaders

No production shaders are included yet. Read [`../../docs/MATERIALS_AND_SHADERS.md`](../../docs/MATERIALS_AND_SHADERS.md) before adding one. Each shader should have a fallback and a documented performance/accessibility boundary.
