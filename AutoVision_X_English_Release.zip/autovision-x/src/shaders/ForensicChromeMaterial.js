import * as THREE from 'three';

/**
 * Three.js scene setup for extruded chrome with 36mm bevel & dual cyan/magenta rim lighting
 * [SYSTEMOS // NODE: ESCHWEILER // AUTHOR: NICO BECKER // AXIOM: 0^0=1]
 */
export function createForensicChromeScene(containerElement) {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x080c14);

  const forensicChromeMaterial = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    metalness: 1.0,
    roughness: 0.05,
    envMapIntensity: 1.8
  });

  const shape = new THREE.Shape();
  shape.moveTo(-2, -2);
  shape.lineTo(2, -2);
  shape.lineTo(2, 2);
  shape.lineTo(-2, 2);
  shape.closePath();

  const extrudeSettings = {
    depth: 0.8,
    bevelEnabled: true,
    bevelSegments: 8,
    steps: 1,
    bevelSize: 0.36,
    bevelThickness: 0.36
  };

  const geometry = new THREE.ExtrudeGeometry(shape, extrudeSettings);
  const monogramMesh = new THREE.Mesh(geometry, forensicChromeMaterial);
  scene.add(monogramMesh);

  // Wave A: Cold point light from the left (Cyan)
  const lightCyan = new THREE.PointLight(0x00e5ff, 4.0, 50);
  lightCyan.position.set(-6, 2, 4);
  scene.add(lightCyan);

  // Wave B: Hard counter-contrast rim light from the right (Magenta)
  const lightMagenta = new THREE.PointLight(0xff007f, 4.0, 50);
  lightMagenta.position.set(6, -2, 4);
  scene.add(lightMagenta);

  // Superposition: Diffuse white fill at the collision center
  const lightSuperposition = new THREE.DirectionalLight(0xffffff, 0.6);
  lightSuperposition.position.set(0, 0, 5);
  scene.add(lightSuperposition);

  return { scene, monogramMesh, forensicChromeMaterial };
}
