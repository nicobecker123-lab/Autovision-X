# Tests

Run `python scripts/validate_tokens.py` from the repository root. This currently checks JSON parsing and required color-token presence only. It is not a UI, security, accessibility, or production test suite.
