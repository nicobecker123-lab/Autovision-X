# Geometry and Layout

- **Conceptual grid:** 60 px base grid for large-screen compositions. Adapt responsively rather than forcing a fixed desktop grid on mobile.
- **Chamfer motif:** 45° clipped corners for selected containers, controls, or status plates. Do not clip focus rings or reduce hit targets.
- **Spacing:** golden-ratio-inspired relationships may guide composition, but use a consistent token scale for implementation.
- **Alignment:** telemetry columns should align numerically; use tabular numerals where available.
- **Density:** prioritize scanability over maximum data packing.
- **Responsive behavior:** collapse panels and reduce decoration before hiding critical status or provenance.

The grid, chamfer, and golden-ratio references are visual guidelines, not measured physical laws or performance guarantees.
