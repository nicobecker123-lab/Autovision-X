# Color Matrix

| Token | Hex | Role | Guardrail |
|---|---|---|---|
| `hyper-dark` | `#080C14` | Main background | Preserve readable contrast |
| `hyper-surface` | `#0E1524` | Panels and cards | Separate surfaces structurally |
| `hyper-border` | `#1F2B42` | Dividers and outlines | Do not rely on border alone |
| `hyper-cyan` | `#00E5FF` | Telemetry / data flow | Not automatically a success state |
| `hyper-green` | `#00FFAA` | Integrity / positive state | Use only with explicit evidence |
| `hyper-magenta` | `#FF007F` | Veto / mutation / divergence | Include a textual status |
| `hyper-yellow` | `#FFEA00` | Warning / transition | Explain the required action |
| `laser-core` | `#FF0000` | Highest-priority focus | Reserve for rare critical emphasis |

## Semantic rule

A token's intended meaning is a design convention. It is not a claim about the underlying system. The same semantic status must remain understandable in monochrome and for users who cannot distinguish the colors.
