# Design Axioms

## A1 — MATERIALIZATION != REALITY

A rendered view, generated image, demo, animation, or simulation is an artifact. It is not proof that the represented event happened.

## A2 — ZERO-OVERCLAIM

Every claim must be bounded by the evidence available. Do not say a component is implemented, tested, secure, deployed, or verified unless that status has been established.

## A3 — Evidence before status

Every consequential status should identify its evidence source, timestamp where appropriate, and validation boundary.

## A4 — Unknown is a valid state

If evidence is missing, stale, contradictory, or unavailable, show `UNKNOWN`, `INCONCLUSIVE`, or an equivalent explicit state. Never coerce uncertainty into success.

## A5 — Separate validation from execution

A validation result means the stated checks passed. It does not mean an external action was executed.

## A6 — Color is not evidence

Colors communicate intent. They do not certify integrity, authorization, or correctness. Pair color with text and, where useful, an icon.

## A7 — Effects remain subordinate

Glitch, scanlines, chromatic offsets, and sound must not obstruct essential content or controls.

## A8 — Motion and sound are opt-in

Respect reduced-motion preferences, browser audio policies, and explicit user controls.

## A9 — Fail closed

If a gate cannot establish its required conditions, it must not report success.

## A10 — No hidden authority

Decorative strings, seals, hashes, or kernel-like labels must not be presented as authentication unless backed by an actual documented verification mechanism.
