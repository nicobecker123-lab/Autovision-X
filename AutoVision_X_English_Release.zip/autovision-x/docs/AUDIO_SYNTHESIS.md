# Audio Synthesis & Acoustic Signatures

AutoVision X strictly segregates deterministic system cues (boot cues & anthems) from reactive mathematical oscillator synthesis during runtime.

## 1. Planned Boot Stinger (Nokia 2000s Heritage)
- **Audio URI:** https://suno.com/s/GLrbClR6VusQhJaj
- **Concept:** Early-2000s cellular polyphony (Nokia ringtone & menu chime heritage) acting as an acoustic initialization cue for `NODE_INIT`.
- **Specification:** See [`../src/audio/BOOT_STINGER.md`](../src/audio/BOOT_STINGER.md)

## 2. ⭐ Curated Favourite: Core System Anthem
- **Audio URI:** https://suno.com/s/C9tg1ssd3GnXeDhH
- **Status:** ⭐ **FAVOURITE**
- **Concept:** Official showcase and release soundtrack; primary sonic anchor of the system.
- **Specification:** See [`../src/audio/FAVOURITE_TRACK.md`](../src/audio/FAVOURITE_TRACK.md)

## 3. Web Audio Oscillators
Implemented in [`../src/audio/ForensicAudioEngine.js`](../src/audio/ForensicAudioEngine.js):
- **Click / Confirm:** 880 Hz Triangle Wave (40ms linear decay)
- **Audit Pass:** 523.25 Hz Sine Wave (Pure C5, unmodulated)
- **Veto Alert:** 110 Hz Sawtooth Wave (asymmetric saturation)
- **Hash Injection:** 1200 Hz -> 150 Hz Sawtooth Sweep (80ms)

## 4. Governance & Safety
- Audio remains silent by default until explicit user interaction.
- Persistent mute/disable control.
- Volume ceiling to prevent transient hearing fatigue.
