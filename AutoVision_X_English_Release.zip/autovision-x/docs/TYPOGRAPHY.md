# Typography

## Families

- **Display / headings:** Space Grotesk
- **Telemetry / code / IDs:** JetBrains Mono
- **Fallback:** system sans-serif for display text; `ui-monospace, SFMono-Regular, Consolas, monospace` for telemetry

Use locally hosted fonts or documented external font loading. Do not make core content depend on a third-party font service being reachable.

## Hierarchy

1. Display title: concise, high contrast
2. Section title: clear and stable
3. Operational label: compact, uppercase only where useful
4. Telemetry value: monospaced and aligned
5. Evidence/source metadata: readable, not visually buried
6. Helper text: never below comfortable reading size

Avoid long passages in all caps. Preserve selectable text; do not rasterize essential labels into decorative artwork.
