# ZERO-OVERCLAIM Policy

## Allowed status language

- `SPECIFIED`: described in documentation
- `IMPLEMENTED`: code exists in the target branch
- `TESTED`: a named test was executed and its result recorded
- `VALIDATED`: stated acceptance criteria passed within a declared boundary
- `DEPLOYED`: deployment evidence is available
- `VERIFIED`: a specific verification method and evidence are identified
- `INCONCLUSIVE`: evidence is insufficient or ambiguous
- `BLOCKED`: a named prerequisite prevents the next step
- `SIMULATED`: produced in a simulation or mock environment

These terms are not interchangeable. Use only the strongest status supported by evidence.

## Example

Bad: “Integrity verified” because the UI shows a green seal.

Better: “The local token schema validation passed. No runtime integrity, security, or deployment verification was performed.”

## Release evidence

For every release, record:
- commit or artifact identifier;
- exact commands/tests executed;
- pass/fail output;
- environment and limitations;
- unresolved blockers;
- whether results are local, simulated, or production-derived.
