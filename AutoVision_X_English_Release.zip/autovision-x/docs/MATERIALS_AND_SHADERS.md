# Materials, Shaders, and Visual Effects

## Visual treatments

- Chromium-like highlights: use as restrained edge lighting or a small number of focal elements.
- CRT scanlines: low opacity, disable-able, and never applied in a way that reduces text legibility.
- Halftone: reserve for backgrounds or nonessential illustrations.
- Interference: use for explicit transition/error moments, not as a constant obstruction.
- Chromatic offset/glitch: short, low-amplitude, and never the only indication of a state change.

## Implementation contract

Shader files are not included as production implementations in this starter. Add them only with:
1. a documented purpose;
2. a graceful fallback;
3. a reduced-motion / effects-off path;
4. a performance check on target devices;
5. a screenshot or visual regression baseline if appropriate.

## Performance guardrails

Prefer CSS effects for simple cases. Avoid full-screen, high-frequency animation loops where a static texture or brief transition is sufficient. Measure frame rate on actual target hardware before making performance claims.
