# Component Contracts

These are component specifications, not implemented production components.

## StatusGate

**Purpose:** render an explicit state and its evidence boundary.

Required fields:
- `status`: one of a documented finite set;
- `label`: human-readable text;
- `evidence`: source or explanation;
- `updatedAt`: optional timestamp;
- `details`: optional expanded explanation.

Rules:
- Unknown values fail closed.
- Green styling alone cannot indicate verified state.
- `SIMULATED` must remain visible when the underlying result is simulated.

## HashSeal

**Purpose:** display a digest or identifier.

Rules:
- Distinguish a displayed string from a digest computed over a known artifact.
- Show algorithm and input scope when a real digest is used.
- Never imply signature, identity, or authorization from a hash alone.

## TelemetryPanel

**Purpose:** display sourced measurements.

Rules:
- Show units, timestamp, source, and stale/unavailable state.
- Do not replace missing data with plausible-looking values.
- Avoid invented defaults that look like real measurements.

## InterferenceDisplay

**Purpose:** optional visualization of signal variation or an explicitly simulated signal.

Rules:
- Label synthetic data as simulated.
- Provide a static or effects-off mode.
- Keep essential text legible and accessible.
